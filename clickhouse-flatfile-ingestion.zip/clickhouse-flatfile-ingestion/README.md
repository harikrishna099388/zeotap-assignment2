# ClickHouse ↔ Flat File Ingestion Tool

## Links
- ClickHouse GitHub: https://github.com/ClickHouse
- ClickHouse Example Datasets: https://clickhouse.com/docs/getting-started/example-datasets
